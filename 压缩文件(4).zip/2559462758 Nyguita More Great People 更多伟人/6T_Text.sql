-- 6T_Text
-- Author: Nyguita
-- DateCreated: 3/21/2022 1:08:35 AM
--------------------------------------------------------------
INSERT OR REPLACE INTO EnglishText
		(Tag,														Text)
VALUES			 ('LOC_GREATPERSON_NYGUITA_AUGUSTE_PICCARD_ACTIVE',				'Trigger the [ICON_TechBoosted] Eurekas for Radar and Physics. If the Eureka for Radar has already been triggered, grant the technology instead. Stealth units and siege range supports units have +1 Sight.');