include('GreatWorkShowcase');
print('Loading Equally Great Scientists UI Replace');
--Unsubscribe
LuaEvents.GreatWorksOverview_ViewGreatWork.Remove(OnViewGreatWork);
Events.GreatWorkCreated.Remove(OnGreatWorkCreated);

local m_City:table;
local m_CityBldgs:table;
local m_GreatWorks:table;
local m_BuildingID:number = -1;
local m_GreatWorkType:number = -1;
local m_GreatWorkIndex:number = -1;
local m_GalleryIndex:number = -1;
local m_isGallery:boolean = false;

local GREAT_WORK_SCIENCE_TYPE:string = "GREATWORKOBJECT_SCIENCE";
local GREAT_WORK_ENGINEERING_TYPE:string = "GREATWORKOBJECT_ENGINEERING";

BASE_OnViewGreatWork = OnViewGreatWork;
function OnViewGreatWork(city:table, buildingID:number, greatWorkIndex:number)
	m_isGallery = true;
	m_BuildingID = buildingID;
	m_GreatWorkIndex = greatWorkIndex;
	m_City = city;
	if m_City ~= nil then
		m_CityBldgs = m_City:GetBuildings();
		m_GreatWorkType = m_CityBldgs:GetGreatWorkTypeFromIndex(m_GreatWorkIndex);
	end
	BASE_OnViewGreatWork(city,buildingID,greatWorkIndex);
end
BASE_OnGreatWorkCreated = OnGreatWorkCreated;
function OnGreatWorkCreated(playerID:number, creatorID:number, cityX:number, cityY:number, buildingID:number, greatWorkIndex:number)
	if playerID ~= Game.GetLocalPlayer() then
		return;
	end
	m_isGallery = false;
	m_BuildingID = buildingID;
	m_GreatWorkIndex = greatWorkIndex;
	m_City = Cities.GetCityInPlot(Map.GetPlotIndex(cityX, cityY));
	if m_City ~= nil then
		m_CityBldgs = m_City:GetBuildings();
		m_GreatWorkType = m_CityBldgs:GetGreatWorkTypeFromIndex(m_GreatWorkIndex);
	end
	BASE_OnGreatWorkCreated(playerID,creatorID,cityX,cityY,buildingID,greatWorkIndex);
end

BASE_UpdateGreatWork=UpdateGreatWork;
function UpdateGreatWork()
	BASE_UpdateGreatWork();
	local greatWorkInfo:table = GameInfo.GreatWorks[m_GreatWorkType];
	local greatWorkType:string = greatWorkInfo.GreatWorkType;
	local greatWorkCreator:string = Locale.Lookup(m_CityBldgs:GetCreatorNameFromIndex(m_GreatWorkIndex));
	local greatWorkCreationDate:string = Calendar.MakeDateStr(m_CityBldgs:GetTurnFromIndex(m_GreatWorkIndex), GameConfiguration.GetCalendarType(), GameConfiguration.GetGameSpeedType(), false);
	local greatWorkCreationCity:string = Locale.Lookup(m_City:GetName());
	local greatWorkCreationBuilding:string = Locale.Lookup(GameInfo.Buildings[m_BuildingID].Name);
	local greatWorkObjectType:string = greatWorkInfo.GreatWorkObjectType;
	if greatWorkObjectType == GREAT_WORK_SCIENCE_TYPE or greatWorkObjectType == GREAT_WORK_ENGINEERING_TYPE then
		local quoteKey:string = greatWorkInfo.Quote;
		if (quoteKey ~= nil) then
			Controls.GreatWorkImage:SetOffsetY(0);
			local greatWorkTexture:string = greatWorkType:gsub("GREATWORK_", "");
			Controls.GreatWorkImage:SetTexture(greatWorkTexture);
			Controls.WritingName:SetText(Locale.ToUpper(Locale.Lookup(greatWorkInfo.Name)));
			Controls.WritingLine:SetHide(false);
			Controls.WritingQuote:SetText(Locale.Lookup(quoteKey));
			Controls.WritingQuote:SetHide(false);
			Controls.WritingAuthor:SetText("-" .. greatWorkCreator);
			Controls.WritingAuthor:SetHide(false);
			Controls.WritingDeco:SetHide(true);
			Controls.WritingDetails:SetHide(false);
		end
	end
end
--Subscribe with new functions
LuaEvents.GreatWorksOverview_ViewGreatWork.Add(OnViewGreatWork);
Events.GreatWorkCreated.Add(OnGreatWorkCreated);